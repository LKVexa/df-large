# BR-420-09 — Source-to-binary provenance

Decision: **OPERATIONAL** in the 4.2.0 host-reference native-semantic-authority scope.

Atomic requirements: 7. Fresh semantic, operational, sanitizer, deterministic-rebuild, size, provenance and independent-verifier evidence passes.

External hardware, issuer certification, native-Windows OS execution and third-party certification are not asserted by this host qualification.
